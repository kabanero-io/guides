package dev.appsody.starter;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/starter")
public class StarterApplication extends Application {

}
